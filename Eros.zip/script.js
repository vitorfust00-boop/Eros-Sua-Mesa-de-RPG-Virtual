document.addEventListener('DOMContentLoaded', () => {
    // --- Estado da Aplicação ---
    let currentUser = {
        nickname: '',
        isDM: false
    };
    let currentRoomCode = '';

    // --- Elementos da DOM ---
    const screens = {
        login: document.getElementById('login-screen'),
        room: document.getElementById('room-screen')
    };

    // Inputs de Login
    const nicknameInput = document.getElementById('nickname');
    const roomCodeInput = document.getElementById('room-code-input');
    const btnCreateRoom = document.getElementById('btn-create-room');
    const btnJoinRoom = document.getElementById('btn-join-room');
    const loginError = document.getElementById('login-error');

    // Elementos da Sala
    const displayRoomCode = document.getElementById('display-room-code');
    const displayUserInfo = document.getElementById('user-info');
    const playersList = document.getElementById('players-list');
    const publicDiceLog = document.getElementById('dice-results');
    
    // Mestre
    const btnBecomeDM = document.getElementById('btn-become-dm');
    const btnDMScreen = document.getElementById('btn-dm-screen');
    const dmModal = document.getElementById('dm-modal');
    const btnCloseDM = document.getElementById('btn-close-dm');

    // Imagens Públicas
    const mainImage = document.getElementById('main-image');
    const noImageText = document.getElementById('no-image-text');

    // --- Funções de Banco de Dados Local (LocalStorage) ---
    // Isso permite que várias abas abertas no mesmo navegador sincronizem os dados!
    function getRooms() {
        const rooms = localStorage.getItem('eros_rooms');
        return rooms ? JSON.parse(rooms) : {};
    }

    function saveRooms(rooms) {
        localStorage.setItem('eros_rooms', JSON.stringify(rooms));
    }

    function getRoom(code) {
        return getRooms()[code];
    }

    function updateRoom(code, updater) {
        const rooms = getRooms();
        if (rooms[code]) {
            rooms[code] = updater(rooms[code]);
            saveRooms(rooms);
            renderRoom(rooms[code]); // Atualiza a própria tela
        }
    }

    // --- Funções Auxiliares ---
    function generateRoomCode() {
        const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789ÁÉÍÓÚáéíóúÂÊÎÔÛâêîôûÃÕãõÇç';
        const rooms = getRooms();
        let code = '';
        let isUnique = false;
        
        while (!isUnique) {
            code = '';
            for(let i=0; i<5; i++) {
                code += chars.charAt(Math.floor(Math.random() * chars.length));
            }
            if (!rooms[code]) isUnique = true;
        }
        return code;
    }

    function switchScreen(screenName) {
        Object.values(screens).forEach(s => s.classList.remove('active'));
        screens[screenName].classList.add('active');
    }

    function renderRoom(roomData) {
        if (!roomData) return;
        
        // Atualiza Lista de Jogadores
        playersList.innerHTML = '';
        roomData.players.forEach(player => {
            const li = document.createElement('li');
            li.textContent = player.name;
            if (player.isDM) {
                const badge = document.createElement('span');
                badge.className = 'dm-badge';
                badge.textContent = 'MESTRE';
                li.appendChild(badge);
            }
            playersList.appendChild(li);
        });

        // Oculta/Mostra botão Virar Mestre baseado em se já tem um mestre
        const hasDM = roomData.players.some(p => p.isDM);
        if (hasDM && !currentUser.isDM) {
            btnBecomeDM.classList.add('hidden'); // Alguém já é mestre
        } else if (!hasDM) {
            btnBecomeDM.classList.remove('hidden'); // Ninguém é mestre ainda
        }

        // Atualiza Logs Públicos (Apenas adiciona os novos para não piscar a tela toda hora)
        publicDiceLog.innerHTML = '';
        roomData.logs.forEach(logText => {
            const entry = document.createElement('div');
            entry.className = 'log-entry';
            entry.innerHTML = logText;
            publicDiceLog.appendChild(entry);
        });
        publicDiceLog.scrollTop = publicDiceLog.scrollHeight; // Auto-scroll

        // Atualiza Imagem Pública
        if (roomData.publicImage) {
            mainImage.src = roomData.publicImage;
            mainImage.classList.remove('hidden');
            noImageText.classList.add('hidden');
            // Também atualiza o painel do mestre se estiver aberto
            document.getElementById('dm-current-public-img').src = roomData.publicImage;
            document.getElementById('dm-current-public-img').classList.remove('hidden');
        } else {
            mainImage.classList.add('hidden');
            noImageText.classList.remove('hidden');
            document.getElementById('dm-current-public-img').classList.add('hidden');
        }
    }

    // --- Sincronização entre Abas ---
    window.addEventListener('storage', (e) => {
        if (e.key === 'eros_rooms' && currentRoomCode) {
            const room = getRoom(currentRoomCode);
            if (room) {
                renderRoom(room);
            } else {
                alert("A sala foi encerrada.");
                location.reload();
            }
        }
    });

    // Remove jogador ao fechar a aba
    window.addEventListener('beforeunload', () => {
        if (currentRoomCode) {
            updateRoom(currentRoomCode, room => {
                room.players = room.players.filter(p => p.name !== currentUser.nickname);
                if (room.players.length === 0) {
                    // Se não sobrou ninguém, a sala deixa de existir e o código pode ser reutilizado
                    const rooms = getRooms();
                    delete rooms[currentRoomCode];
                    saveRooms(rooms);
                    return null; // A sala foi deletada
                }
                return room;
            });
        }
    });

    // --- Lógica de Login ---
    function handleLogin(isCreating) {
        const nickname = nicknameInput.value.trim();
        let code = roomCodeInput.value.trim(); // Não converte para UpperCase porque letras minúsculas e acentos importam agora

        if (!nickname) {
            loginError.textContent = "Por favor, digite seu apelido.";
            loginError.classList.remove('hidden');
            return;
        }

        const rooms = getRooms();

        if (isCreating) {
            code = generateRoomCode();
            rooms[code] = {
                players: [{ name: nickname, isDM: false }],
                logs: [`<em>Sala criada por ${nickname}</em>`],
                publicImage: ''
            };
            saveRooms(rooms);
        } else {
            if (!code) {
                loginError.textContent = "Para entrar, digite o código da sala.";
                loginError.classList.remove('hidden');
                return;
            }
            if (!rooms[code]) {
                loginError.textContent = "Sala não encontrada. Verifique o código (letras maiúsculas/minúsculas importam).";
                loginError.classList.remove('hidden');
                return;
            }
            
            // Verifica se o nome já existe
            const nameExists = rooms[code].players.some(p => p.name.toLowerCase() === nickname.toLowerCase());
            if (nameExists) {
                loginError.textContent = "Este apelido já está em uso nesta sala. Escolha outro.";
                loginError.classList.remove('hidden');
                return;
            }

            rooms[code].players.push({ name: nickname, isDM: false });
            rooms[code].logs.push(`<em>${nickname} entrou na sala!</em>`);
            saveRooms(rooms);
        }

        loginError.classList.add('hidden');
        currentUser.nickname = nickname;
        currentRoomCode = code;

        displayRoomCode.textContent = currentRoomCode;
        displayUserInfo.innerHTML = `Logado como: <strong>${nickname}</strong>`;
        
        switchScreen('room');
        renderRoom(getRoom(currentRoomCode));
    }

    btnCreateRoom.addEventListener('click', () => handleLogin(true));
    btnJoinRoom.addEventListener('click', () => handleLogin(false));

    // --- Lógica de Dados ---
    function rollDice(sides) {
        return Math.floor(Math.random() * sides) + 1;
    }

    function addPrivateLog(text) {
        const privateDiceLog = document.getElementById('private-dice-results');
        const entry = document.createElement('div');
        entry.className = 'log-entry';
        entry.innerHTML = text;
        privateDiceLog.appendChild(entry);
        privateDiceLog.scrollTop = privateDiceLog.scrollHeight;
    }

    // Dados Públicos
    document.querySelectorAll('.dice-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const sides = parseInt(btn.getAttribute('data-sides'));
            const result = rollDice(sides);
            const logMsg = `<strong>${currentUser.nickname}</strong> rolou 1d${sides} <br> Resultado: <strong style="font-size: 1.2em; color: var(--accent);">${result}</strong>`;
            
            updateRoom(currentRoomCode, room => {
                room.logs.push(logMsg);
                return room;
            });
        });
    });

    // Dados Privados (Mestre)
    document.querySelectorAll('.private-dice-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const sides = parseInt(btn.getAttribute('data-sides'));
            const result = rollDice(sides);
            addPrivateLog(`Rolagem Oculta (1d${sides}) <br>Resultado: <strong style="color: var(--danger);">${result}</strong>`);
        });
    });

    // --- Lógica do Mestre ---
    btnBecomeDM.addEventListener('click', () => {
        const room = getRoom(currentRoomCode);
        const hasDM = room.players.some(p => p.isDM);
        
        if (hasDM) {
            alert("Já existe um mestre nesta sala!");
            return;
        }

        currentUser.isDM = true;
        
        updateRoom(currentRoomCode, r => {
            const player = r.players.find(p => p.name === currentUser.nickname);
            if(player) player.isDM = true;
            r.logs.push(`<em>${currentUser.nickname} assumiu o Escudo do Mestre!</em>`);
            return r;
        });
        
        btnBecomeDM.classList.add('hidden');
        btnDMScreen.classList.remove('hidden');
    });

    btnDMScreen.addEventListener('click', () => dmModal.classList.remove('hidden'));
    btnCloseDM.addEventListener('click', () => dmModal.classList.add('hidden'));

    window.addEventListener('click', (e) => {
        if (e.target === dmModal) dmModal.classList.add('hidden');
    });

    // --- Abas do Escudo do Mestre ---
    const tabBtns = document.querySelectorAll('.tab-btn');
    const tabPanes = document.querySelectorAll('.tab-pane');

    tabBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            tabBtns.forEach(b => b.classList.remove('active'));
            tabPanes.forEach(p => p.classList.remove('active'));
            
            btn.classList.add('active');
            const targetId = btn.getAttribute('data-target');
            document.getElementById(targetId).classList.add('active');
        });
    });

    // --- Lógica de Fichas (Salvas apenas localmente na máquina do mestre por enquanto) ---
    const monstersList = document.getElementById('monsters-list');
    const npcsList = document.getElementById('npcs-list');
    const btnAddMonster = document.getElementById('btn-add-monster');
    const btnAddNpc = document.getElementById('btn-add-npc');
    const monsterTemplate = document.getElementById('monster-template');
    const npcTemplate = document.getElementById('npc-template');

    function createSheet(template, container) {
        const clone = template.content.cloneNode(true);
        const card = clone.querySelector('.sheet-card');
        const removeBtn = clone.querySelector('.btn-remove-sheet');
        removeBtn.addEventListener('click', () => card.remove());
        container.appendChild(clone);
    }

    btnAddMonster.addEventListener('click', () => createSheet(monsterTemplate, monstersList));
    btnAddNpc.addEventListener('click', () => createSheet(npcTemplate, npcsList));

    // --- Lógica de Imagens ---
    const privateImgUrlInput = document.getElementById('private-img-url');
    const btnAddPrivateImg = document.getElementById('btn-add-private-img');
    const privateImagesList = document.getElementById('private-images-list');

    btnAddPrivateImg.addEventListener('click', () => {
        const url = privateImgUrlInput.value.trim();
        if (url) {
            const img = document.createElement('img');
            img.src = url;
            img.className = 'private-img-item';
            img.onerror = () => { alert("Erro ao carregar a imagem privada."); img.remove(); };
            privateImagesList.appendChild(img);
            privateImgUrlInput.value = '';
        }
    });

    const publicImgUrlInput = document.getElementById('public-img-url');
    const btnSetPublicImg = document.getElementById('btn-set-public-img');

    btnSetPublicImg.addEventListener('click', () => {
        const url = publicImgUrlInput.value.trim();
        updateRoom(currentRoomCode, room => {
            room.publicImage = url;
            if (url) {
                room.logs.push(`<em>O Mestre alterou a imagem do cenário.</em>`);
            }
            return room;
        });
        publicImgUrlInput.value = '';
    });
});
